<?php

namespace app\index\controller;
use think\Controller;
use think\Db;

class Index extends Controller{

    public function index($id = '') {
        echo "<span style='font-size:30px'>error</span>";
    }

    public function hello($id, $m = 'down') {
        $did = $this->decode($id);
        $result = Db::table('c_dl')->where('id',$did)->find();
        $url = $result['url'];
        Header("HTTP/1.1 303 See Other");
        Header("Location: $url");
        exit();
    }

    function decode($string = '', $skey = 'qw') {
        $strArr = str_split(str_replace(array('', '', ''), array('=', '+', '/'), $string), 2);
        $strCount = count($strArr);
        foreach (str_split($skey) as $key => $value)
            $key <= $strCount && isset($strArr[$key]) && $strArr[$key][1] === $value && $strArr[$key] = $strArr[$key][0];
        return base64_decode(join('', $strArr));
    }

}

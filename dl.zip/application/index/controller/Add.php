<?php

namespace app\index\controller;

use think\Controller;
use think\Db;

class Add extends Controller {

    public function index($url) {
        if ($this->CheckUrl($url)) {
            $result = Db::table('c_dl')->where('url', $url)->find();
            if (!$result) {
                $data = ['url' => $url];
                $result = Db::name('dl')->insertGetId($data);
                echo $this->encode($result);
            } else {
                echo $this->encode($result['id']);
            }
        } else {
            echo -1;
        }
    }

    function encode($string = '', $skey = 'qw') {
        $strArr = str_split(base64_encode($string));
        $strCount = count($strArr);
        foreach (str_split($skey) as $key => $value)
            $key < $strCount && $strArr[$key] .= $value;
        return str_replace(array('=', '+', '/'), array('', '', ''), join('', $strArr));
    }

    function CheckUrl($C_url) {
        $str = "/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/";
        if (!preg_match($str, $C_url)) {
            return false;
        } else {
            return true;
        }
    }

}
